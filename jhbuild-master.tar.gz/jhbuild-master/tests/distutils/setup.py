
from distutils.core import setup

setup(name='hello', scripts=['hello'])
