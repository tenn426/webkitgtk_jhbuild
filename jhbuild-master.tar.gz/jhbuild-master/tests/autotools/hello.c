
#include <stdio.h>

int main()
{
  printf("Hello world (autotools)\n");
  return 0;
}
