
#include <libhello/libhello.h>

int main()
{
  greet_world("library test");
  return 0;
}
