
void greet_world(const char *text);
