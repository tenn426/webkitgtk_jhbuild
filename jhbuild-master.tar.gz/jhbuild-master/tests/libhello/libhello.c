
#include <stdio.h>

#include "libhello.h"


void greet_world(const char *text)
{
  printf("Hello world (%s)\n", text);
}
